package com.bocxy.landDigit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LandDigitApplicationTests {

	@Test
	void contextLoads() {
	}

}
